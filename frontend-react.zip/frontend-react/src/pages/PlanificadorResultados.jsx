/**
 * Página de resultados generados por el planificador.
 */
export default function PlanificadorResultados() {
  return (
    <div className="planificador-resultados-page card">
      <h2>Planificador - Resultados</h2>
      <p>Recetas generadas por días (comida y cena).</p>
    </div>
  );
}
