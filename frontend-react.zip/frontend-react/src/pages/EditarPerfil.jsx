/**
 * Página para editar perfil de usuario.
 */
export default function EditarPerfil() {
  return (
    <div className="editar-perfil-page card">
      <h2>Editar Perfil</h2>
      <p>Formulario para editar los datos del usuario (próximamente).</p>
    </div>
  );
}
